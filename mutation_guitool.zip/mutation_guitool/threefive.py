def T35():
    if 3 >= 5:
        return "yes"
    else:
        return "no"
def T69():
    if 6+1 < 9:
        return "yes"
    else:
        return "no"

# def Tandor():
#     if 6>9 and 10<12:
#         return "yes"
#     else:
#         return "no"
# def Tbi():
#     if 6>>1 == 3:
#         return "yes"
#     else:
            #         return "no"